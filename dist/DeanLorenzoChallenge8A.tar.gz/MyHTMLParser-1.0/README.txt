This package inherits the HTMLParser class to scrape the IP address from the website
checkip.dydns.org.

To use it you can use the following code:

import my_html_parser

ip = my_html_parser.get_ip_address()